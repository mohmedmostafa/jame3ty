const AuthJwt = require('./authJwt');

module.exports = {
  AuthJwt,
};
