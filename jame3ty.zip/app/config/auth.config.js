module.exports = {
  secret: 'sola-secret-key',
};
